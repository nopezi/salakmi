# salakmi-lab
Website buat pembelajaran hacking website. 

# Latar Belakang
Dalam pembelajaran Ethical Hacking yang di ampu oleh penulis pada tahun 2016 yang mengacu pada buku buku Ethical Hacking selama setahun membuat penulis menyadari bahwa praktek melakukan serangan terhadap Website dalam proses pembelajaran diperlukan untuk membentuk pemahaman bagi pemula yang mempelajari Ethical Hacking. Hal ini tidak hanya di rasakan oleh penulis namun juga dikeluhkan oleh teman teman baik di dunia maya maupun di dunia nyata. Website yang dapat diserang dibutuhkan untuk proses pembelajaran dalam Lab Hacking karena penyerangan kepada Website yang sebenarnya di internet adalah tindakan ilegal dan hal yang sepatutnya dihindari dalam pembelajaran Ethical Hacking. 

Pada jajak pendapat yang diadakan oleh Fanspage Salakmi Belajar menyimpulkan sebanyak 87 persen responden sangat setuju bahwa Website Lab Hacking berbahasa indonesia dibutuhkan. Sedangkan lima persen lainnya juga ikut menyetujui sehingga jika di totalkan ada 92 persen responden yang menyetujui dibutuhkannya Website yang dibuat sengaja memiliki kerentanan untuk dipelajari. Jajak pendapat ini dibuat dan disebarkan pada sepuluh grup facebook besar yang bertemakan Hacking atau penetration testing dan di respon oleh 156 orang.
Berdasarkan pada pengalaman dan data yang di dapatkan dari jajak pendapat penulis mengusulkan sebuah aplikasi web yang dapat digunakan sebagai Lab Hacking sehingga mempermudah pembelajaran Hacking dan meminimalisir tindakan ilegal dalam melakukan pembelajaran Ethical Hacking.

# Mengapa salakmi lab dibuat berbahasa indonesia?
Sederhana, beberapa kali penulis diminta untuk mengajarkan exploitasi terhadap web baik via online maupun offline, ketika penulis mengusulkan penggunaan webiste serupa seperti DVWA dan BWAPP ternyata keluhannya sama, "Yah.. bahasa inggris..". Jadi penulis buat berbahasa indonesia.

# Kelebihannya dibanding yang sudah ada?
Untuk pemula yang belum pernah mencoba, salakmi menyediakan tutorial untuk exploitasi kerentanannya kok.. :)

# Bisakah ikut berkontribusi ?
Bisa sekali..
Harapan penulis adalah dapat memperbaiki tampilan dari SalakMi lab ( penulis nggak jago koding tampilan ), juga menambah fitur fitur kerentanan yang lain.
Jika berminat kontak admin dari Fanspage SalakMI Belajar ya..


# Author
Zifor Syuhada

# Facebook

https://www.facebook.com/SalakMibelajar/

# Telegram

https://telegram.dog/salakMI

# Referensi

  # Ide dan beberapa source 

  https://github.com/ethicalhack3r/DVWA
  
  https://github.com/snoopysecurity/dvws
  
  http://www.itsecgames.com/


