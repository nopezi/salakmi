<?php

include_once "../desain/sider.php";
include_once "../desain/setcss.php";

$id='exec';

// echo "<div class=\"main\">";
// include_once "../desain/header.php";

?>










<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Salakmi</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <style src="../js/bootstrap.js"></style>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  

<!--=================== KEPALA ===================-->

  
<?php include_once "../desain/header.php"; ?>

    </div>
  </div>




<!--==================== BADAN  ====================-->





<div class="">
  <div class="container">
  <div class="">
    <div class="">
      



      <div class="col-md-8">
        <div class="badan">
          
          
            <div class="isi">
              <p>Bejo membuat sebuah fungsi di websitenya untuk melakukan ping ke server lain. 
Dengan kemampuan pas pasan seperti inilah fungsi yang ia buat</p>
            </div>


        <div class="bejo">
             <form class="" name="ping" action="#" method="post">
                <span  class="input-group-addon" id="basic-addon1">Enter an IP address</label>
                <input  style="margin-top: 5px;"  type="text" name="ip" class="form-control" aria-describedby="basic-addon1">
                <input  style="margin-top: 5px;"  type="submit" name="Submit" value="Submit" class="btn btn-success">
            </form>
            <?php

// echo "<form name=\"ping\" action=\"#\" method=\"post\">
//             <p>
//                 Enter an IP address:
//                 <input type=\"text\" name=\"ip\" size=\"30\">
//                 <input type=\"submit\" name=\"Submit\" value=\"Submit\">
//             </p>\n
//             </form>";

if( isset( $_POST[ 'Submit' ]  ) ) {
    
    $target = $_REQUEST[ 'ip' ];

    
    if( stristr( php_uname( 's' ), 'Windows NT' ) ) {
        // Windows
        $cmd = shell_exec( 'ping  ' . $target );
    }
    else {
        // *nix
        $cmd = shell_exec( 'ping  -c 4 ' . $target );
    }

    
    echo "<pre>{$cmd}</pre>";
}


// echo "</div>";
?> 
        </div>
          
          
        </div>

        <?php include_once "../desain/tombol.php"; ?>
      </div>

     



<!--===================== END BADAN =====================-->




<!--===================== KANAN ==========================-->


    <?php require_once '../desain/kanan.php'; ?>

        
      
<!--===================== END KANAN ==========================-->

    </div>

  </div>

<!--===================== FOOTER =============================-->

  <?php require_once '../desain/footer.php'; ?>


<!--===================== END KANAN ============================-->




</div>





</div>






</body>
</html> 








<!--<div style="position:absolute;bottom:0;right:10px;">asd</div>-->