






<?php

include_once "../desain/sider.php";
include_once "../desain/setcss.php";

$id='exec';

// echo "<div class=\"main\">";
// include_once "../desain/header.php";

?>










<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Salakmi</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <style src="../js/bootstrap.js"></style>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  

<!--=================== KEPALA ===================-->

  
<?php include_once "../desain/header.php"; ?>

    </div>
  </div>




<!--==================== BADAN  ====================-->





<div class="">
  <div class="container">
  <div class="">
    <div class="">
      



      <div class="col-md-8">
        <div class="badan">
          
          
            <div class="isi">
              <p>Bejo membuat sebuah fungsi di websitenya untuk melakukan ping ke server lain. 
Dengan kemampuan pas pasan seperti inilah fungsi yang ia buat</p>
            </div>


        <div class="bejo">
             




<?php

$id = 'upload';

echo "<form enctype=\"multipart/form-data\" action=\"#\" method=\"POST\">
			<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"10000000\" />
			Pilih gambar :<br /><br />
			<input name=\"uploaded\" type=\"file\" /><br />
			<br />
			<input type=\"submit\" name=\"Upload\" value=\"Upload\" class=\"btn btn-success\" />\n
			</form>";



if( isset( $_POST[ 'Upload' ] ) ) {
	// Where are we going to be writing to?
	$target_path  = "../macemmacem/uploads/";
	$target_path .= basename( $_FILES[ 'uploaded' ][ 'name' ] );

	
	// Can we move the file to the upload folder?
	if( !move_uploaded_file( $_FILES[ 'uploaded' ][ 'tmp_name' ], $target_path ) ) {
		// No
		echo '<pre>Gambar kamu belum ke upload.</pre>';
	}
	else {
		// Yes!
		echo "<pre>{$target_path} Sukses Upload gambar!</pre>";
	}
}



?>



        </div>
          
          
        </div>

        <?php include_once "../desain/tombol.php"; ?>
      </div>

     



<!--===================== END BADAN =====================-->




<!--===================== KANAN ==========================-->


    <?php require_once '../desain/kanan.php'; ?>

        
      
<!--===================== END KANAN ==========================-->

    </div>

  </div>

<!--===================== FOOTER =============================-->

  <?php require_once '../desain/footer.php'; ?>


<!--===================== END KANAN ============================-->




</div>





</div>






</body>
</html> 








<!--<div style="position:absolute;bottom:0;right:10px;">asd</div>-->