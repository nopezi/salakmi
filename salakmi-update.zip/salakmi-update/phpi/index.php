
<?php

include_once "../desain/sider.php";
include_once "../desain/setcss.php";

$id='phpi';







// echo "<div class=\"main\">";
// include_once "../desain/header.php";

?>










<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Salakmi</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <style src="../js/bootstrap.js"></style>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  

<!--=================== KEPALA ===================-->

  
<?php include_once "../desain/header.php"; ?>

    </div>
  </div>




<!--==================== BADAN  ====================-->





<div class="">
  <div class="container">
  <div class="">
    <div class="">
      



      <div class="col-md-8">
        <div class="badan">
          
          
            <div class="isi">
              <p>Bejo membuat sebuah fungsi di websitenya untuk melakukan ping ke server lain. 
Dengan kemampuan pas pasan seperti inilah fungsi yang ia buat</p>
            </div>


        <div class="bejo">


<p> Halaman ini akan merefleksikan pesan yang kamu tulis di url, klik  

<a href="<?php echo($_SERVER["SCRIPT_NAME"]);?>?pesan=test"> Pesan </a>...</p>

<?php

if(isset($_REQUEST["pesan"]))
{
	@eval ("echo " .$_REQUEST["pesan"]. ";");
}

?>


        </div>
          
          
        </div>

        <?php include_once "../desain/tombol.php"; ?>
      </div>

     



<!--===================== END BADAN =====================-->




<!--===================== KANAN ==========================-->


    <?php require_once '../desain/kanan.php'; ?>

        
      
<!--===================== END KANAN ==========================-->

    </div>

  </div>

<!--===================== FOOTER =============================-->

  <?php require_once '../desain/footer.php'; ?>


<!--===================== END KANAN ============================-->




</div>





</div>






</body>
</html> 








<!--<div style="position:absolute;bottom:0;right:10px;">asd</div>-->