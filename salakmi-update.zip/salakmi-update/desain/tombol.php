

<form>
	<input type="submit" class="btn btn-info fa-input" value="&#xf002; Tampil Source" onclick="javascript:popUp('/salakmi/tampil_source.php?id=<?php echo $id;?>')">
</form>