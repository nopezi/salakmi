


<div class="col-md-13">
        <div class="kaki">
          
          
            <center>
              <div class="isi3" style="width: 500px solid;">
              
                <p>Ini footer :D - Becanda.. Tetap semangat dan terus belajar</p>
                <p>Lab ini bersifat Open Source. Beberapa potongan kode berasal dari kode kode php open source juga.</p>
              
            </div>
            </center>
            <center>&copy; salakmi</center>
            
          
          
        </div>
    </div>