<div class="col-md-4">
        <div class="kanan">
          <div class="">
            
              <div class="isi2">
                <h2>Apa itu salakMI Lab?</h2>
              <p>Adalah Lab hacking Web</p>
              </div>

              <div class="isi2">
                <h2> Dibuat untuk siapa?</h2>
              <p> Semua yang belajar hacking di luar sana. Dan terkhusus komunitas hacking dan mahasiswa Amikom yang tertarik di bidang penetration testing dan Digital Forensics</p>
              </div>

              <div class="isi2">
                <h2> Siapa pembuatnya?</h2>
              <p>Zifor Syuhada<br>
              <p> CEO of SalakMI </p>
              </div>
            
          </div>
        </div>
      </div>