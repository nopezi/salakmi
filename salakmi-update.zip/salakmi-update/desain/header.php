<div class="container">
    <div class="col-md-12">
      <div class="header">
        


        
          <font>

        <a href="/salakmi/" class="fa fa-th-large"> </a>SalakMI Lab</font>
        <button class="tombol" style="float:right;cursor:pointer" onclick="buka()">&#9776; open</button>
        <script type="text/javascript" src="/salakmi/fungsi/fungsi.js"></script>
        
     
    </div>
  </div>


 </div>