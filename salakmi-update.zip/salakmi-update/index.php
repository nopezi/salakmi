<?php

include_once "desain/sider.php";
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"/salakmi/css/styleku.css\">";
echo "<link rel=\"stylesheet\" href=\"/salakmi/fa/css/font-awesome.min.css\">";

// echo "<div class=\"main\">";
// echo "<div class=\"main2\" >";

?>





<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Salakmi</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style src="js/bootstrap.js"></style>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  

<!--=================== KEPALA ===================-->

  
<?php include_once "desain/header.php"; ?>

    </div>
  </div>




<!--==================== BADAN  ====================-->





<div class="">
  <div class="container">
  <div class="">
    <div class="">
      



      <div class="col-md-8">
        <div class="badan">
          
          
            <div class="isi">
               <h1>SalakMI Lab</h1>
               <hr>
            <p>Adalah Web yang di desain untuk di jadikan Lab hacking. Web ini di desain untuk di serang</p>
            <p> Di buat untuk belajar kawan kawan yang tetarik di dunia ethical hacking</p>
            </div>

            <div class="isi2">
              <p>Hint: gunakan nikto terlebih dahulu untuk melakukan scanning, mungkin akan ada hal bermanfaat yang bisa kamu dapatkan</p>
            </div>
          
          
        </div>
      </div>

     



<!--===================== END BADAN =====================-->




<!--===================== KANAN ==========================-->




        <div class="col-md-4">
        <div class="kanan">
          <div class="">
            
              <div class="isi2">
                <h2>Apa itu salakMI Lab?</h2>
              <p>Adalah Lab hacking Web</p>
              </div>

              <div class="isi2">
                <h2> Dibuat untuk siapa?</h2>
              <p> Semua yang belajar hacking di luar sana. Dan terkhusus komunitas hacking dan mahasiswa Amikom yang tertarik di bidang penetration testing dan Digital Forensics</p>
              </div>

              <div class="isi2">
                <h2> Siapa pembuatnya?</h2>
              <p>Zifor Syuhada<br>
              <p> CEO of SalakMI </p>
              </div>
            
          </div>
        </div>
      </div>
      
<!--===================== END KANAN ==========================-->

    </div>

  </div>

<!--===================== FOOTER =============================-->

  <div class="col-md-13">
        <div class="kaki">
          
          
            <center>
              <div class="isi3" style="width: 500px solid;">
              
                <p>Ini footer :D - Becanda.. Tetap semangat dan terus belajar</p>
              
            </div>
            </center>
            <center>&copy; salakmi</center>
            
          
          
        </div>
    </div>


<!--===================== END KANAN ============================-->




</div>





</div>






</body>
</html> 

<!-- 
<div class="col-9">
  <h1>SalakMI Lab</h1>
  <p>Adalah Web yang di desain untuk di jadikan Lab hacking. Web ini di desain untuk di serang</p>
  <p> Di buat untuk belajar kawan kawan yang tetarik di dunia ethical hacking</p>
</div>

<div class="col-3 right">
  <div class="aside">
    <h2>Apa itu salakMI Lab?</h2>
    <p>Adalah Lab hacking Web</p>
    <h2> Dibuat untuk siapa?</h2>
    <p> Semua yang belajar hacking di luar sana. Dan terkhusus komunitas hacking dan mahasiswa Amikom yang tertarik di bidang penetration testing dan Digital Forensics</p>
    <h2> Siapa pembuatnya?</h2>
    <p>Zifor Syuhada<br>
     CEO of SalakMI </p>
  </div>
</div>

</div>
</div> -->
