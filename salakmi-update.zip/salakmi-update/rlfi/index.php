





<?php

include_once "../desain/sider.php";
include_once "../desain/setcss.php";

$id='exec';

// echo "<div class=\"main\">";
// include_once "../desain/header.php";

?>










<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Salakmi</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <style src="../js/bootstrap.js"></style>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  

<!--=================== KEPALA ===================-->

  
<?php include_once "../desain/header.php"; ?>

    </div>
  </div>




<!--==================== BADAN  ====================-->





<div class="">
  <div class="container">
  <div class="">
    <div class="">
      



      <div class="col-md-8">
        <div class="badan">
          
          
            <div class="isi">
              <p>Bejo membuat sebuah fungsi di websitenya untuk melakukan ping ke server lain. 
Dengan kemampuan pas pasan seperti inilah fungsi yang ia buat</p>
            </div>


        <div class="bejo">


<?php 

$id = 'rlfi';




$status = "";

?>

<form class="input-group" name="rfli" action="#" method="get">
    <label class="form-control" id="basic-addon1" readonly>Status mu</label>
    <select name="status" class="form-control" aria-describedby="basic-addon1">

        <option value="jomblo.php">Jomblo</option>
        <option value="single.php">Single</option>
        <option value="complicated.php">Complicated</option>
    </select>
    
    <button style="margin-top: 5px;" type="submit" name="action" value="go" class="btn btn-success">Go</button>
</form>

<!-- echo "<form name=\"rfli\" action=\"#\" method=\"get\">
            <p>
                Status:
                <select name=\"status\">
                    <option value=\"jomblo.php\"> Jomblo </option>
                    <option value=\"single.php\"> Single </option>
                    <option value=\"complicated.php\"> Complicated </option>
                </select>

             <button type=\"submit\" name=\"action\" value=\"go\"> Go </button>
             </form>"; -->

<?php

if(isset($_GET["status"]))
    {
        $status = $_GET["status"];  
        include($status);
    }


?>


        </div>
          
          
        </div>

        <?php include_once "../desain/tombol.php"; ?>
      </div>

     



<!--===================== END BADAN =====================-->




<!--===================== KANAN ==========================-->


    <?php require_once '../desain/kanan.php'; ?>

        
      
<!--===================== END KANAN ==========================-->

    </div>

  </div>

<!--===================== FOOTER =============================-->

  <?php require_once '../desain/footer.php'; ?>


<!--===================== END KANAN ============================-->




</div>





</div>






</body>
</html> 








<!--<div style="position:absolute;bottom:0;right:10px;">asd</div>-->