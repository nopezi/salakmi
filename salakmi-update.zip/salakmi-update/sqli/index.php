















<?php

include_once "../desain/sider.php";
include_once "../desain/setcss.php";



// echo "<div class=\"main\">";
// include_once "../desain/header.php";

?>










<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Salakmi</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <style src="../js/bootstrap.js"></style>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  

<!--=================== KEPALA ===================-->

  
<?php include_once "../desain/header.php"; ?>

    </div>
  </div>




<!--==================== BADAN  ====================-->





<div class="">
  <div class="container">
  <div class="">
    <div class="">
      



      <div class="col-md-8">
        <div class="badan">
          
          
            <div class="isi">
              <p>Bejo membuat sebuah fungsi di websitenya untuk melakukan ping ke server lain. 
Dengan kemampuan pas pasan seperti inilah fungsi yang ia buat</p>
            </div>


        <div class="bejo">

<form action="#" class="input-group">
    <span class="input-group-addon" id="basic-addon1">User Id</span>
    <input type="text" name="id" class="form-control-static" aria-describedby="basic-addon1">
    <input type="submit" name="Submit" value="Submit" class="btn btn-success">
</form>

<?php
//include"../konfig/koneksi.php";

$id = 'sqli';


if( isset( $_GET[ 'Submit' ] ) ) {

    $id = $_GET['id'];

$db = new mysqli('localhost', 'root', '', 'salakmi');

if($db->connect_errno > 0){
    die('Nggak bisa konek ke database [' . $db->connect_error . ']');
}

$sql = "SELECT * FROM `nama` WHERE `id` = '$id'" 
;
?>

<table class="table table-bordered table-hover table-striped">
 <tr>
    <th> Nama </th>
    <th> Alamat </th>

<?php

if(!$result = $db->query($sql)){
    die('Ada eror di query [' . $db->error . ']');
}else if($row = $result->fetch_assoc()){
    echo '<tr> <td>'.$row['nama'] . '</td> <td>' . $row['alamat'] . '</td>';
}

$result->free();
$db->close();



}



?>

</tr></table>

        </div>
          
          
        </div>

        <?php include_once "../desain/tombol.php"; ?>
      </div>

     



<!--===================== END BADAN =====================-->




<!--===================== KANAN ==========================-->


    <?php require_once '../desain/kanan.php'; ?>

        
      
<!--===================== END KANAN ==========================-->

    </div>

  </div>

<!--===================== FOOTER =============================-->

  <?php require_once '../desain/footer.php'; ?>


<!--===================== END KANAN ============================-->




</div>





</div>






</body>
</html> 








<!--<div style="position:absolute;bottom:0;right:10px;">asd</div>--> 